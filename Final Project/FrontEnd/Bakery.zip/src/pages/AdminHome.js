

import React from "react"; 
import ReactDOM from "react-dom";
import { Link } from "react-router-dom";

function AdminHome(){

return(

<div >
    <header className="full_bg">

    <div className="header">
       <div className="container-fluid">
          <div className="row">
             <div >
                <div className="full">
                   <div className="center-desk">
                      <div className="logo">
                         {/* <a href="index.html"><img src="assets/images/logo.png" alt="#" /></a> */}
                      </div>
                   </div>
                </div>
             </div>
            
          </div>
       </div>
    </div>

  
 </header>
 </div>





)




}

export default AdminHome;
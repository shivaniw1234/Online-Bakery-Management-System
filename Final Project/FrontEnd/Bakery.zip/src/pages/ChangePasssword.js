import { useState } from "react"
import { useEffect } from "react";
import axios from "axios";
import Header from "./header"
import { useNavigate } from "react-router";


export default function ChangePassword()
{
    let [oldpwd,setOldpwd]=useState();
    let [newpwd,setNewpwd]=useState();
    
let navigate=useNavigate()

const changepwd=()=>{
    let email=sessionStorage.getItem("username");
    axios.put(`http://localhost:8080/user/changepwd/${email}/${oldpwd}/${newpwd}`,{})
    .then((response) =>{ console.log(response.data); alert("password changed");}
    ).catch(error => console.log(error));
    navigate("/");
}
    
    return(
        <div>
            <Header></Header>
            <center>
                <form>
                enter current password <input type="text" name="oldpwd" placeholder="Enter current password" onChange={(e)=>{setOldpwd(e.target.value)}}/><br/>
                enter new password <input  type="text" name="newpwd" placeholder="Enter new password"onChange={(e)=>{setNewpwd(e.target.value)}}/><br/>
                confirm new password <input type="text" name="newpwd" placeholder="Enter old password" onChange={(e)=>{if(e.target.value!==newpwd) return false;}}/><br/>
                <button type="submit" name="changepassword" class="btn btn-primary" onClick={changepwd}>Change Password</button>
                </form>
            </center>
        </div>
    )
}
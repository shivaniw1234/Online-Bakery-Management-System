import axios from "axios";
import Header from "./header"
import { Link, useLocation } from 'react-router-dom';
import { useEffect } from "react";
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Typography from '@mui/material/Typography';
import { CardActionArea } from '@mui/material';
import { useState } from "react";
export default function OrderHistory()
{
    let [arr,setArr]=useState([])
    
    useEffect(() =>{
       let uid= sessionStorage.getItem("userid");
       console.log("uid",uid);
       axios.get(`http://localhost:8080/order/history/${uid}`,{})
       .then((res)=>{console.log("order",res.data);
  setArr(res.data);
    }).catch((err )=>{console.log("error",err)});
    },[]);


   
    return (
        <div>
            <Header></Header>
            <center><br/><br/><h1>Order History</h1><br/><br/>

                {/* <Link to="cart"  state={{prodid:ele.prodId}}>Add to cart</ Link>  */}
            </center>
            {/* <ol>{arr.map((ele)=>{  
      return ( <CardContent>
        <Typography gutterBottom variant="h5" component="div">
          { ele.pname}
        </Typography>
        <Typography variant="body2" color="text.secondary">
           {ele.cname}
            <h5>Cost:{ele.price}</h5>
        </Typography>
    </CardContent>)
    })}</ol> */}

            <h1> <center>
          &ensp;&nbsp;&nbsp;&nbsp;&nbsp;&ensp;&nbsp;&nbsp;order Id&nbsp;&nbsp;
          &nbsp;&nbsp;&ensp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&ensp;&nbsp;&nbsp;&ensp;order Date&nbsp;&nbsp;&nbsp;&nbsp;&ensp;&nbsp;&nbsp;
        &nbsp;&nbsp;&ensp;&nbsp;&nbsp;  &nbsp;Order Price&nbsp;&nbsp;
                    &nbsp;&nbsp;&ensp;&nbsp;&nbsp; &nbsp;&nbsp;order Id&nbsp;&nbsp;
                     &nbsp;&nbsp;&ensp;&nbsp;&nbsp;&ensp;order Date&nbsp;&nbsp;&nbsp;&nbsp;&ensp;&nbsp;&nbsp;
                   &nbsp;&nbsp;&ensp;&nbsp;&nbsp;  &nbsp;Order Price&nbsp;&nbsp;&ensp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    
         <div className="container">
         <div className="row">
                {
                    arr.map((ele, index) => {
                        return (<span key={index}>
                            <tr>
                            <td>
                            <div className="row-lg-4"><br/>
                            &ensp;&ensp; &ensp;&nbsp;&ensp;&nbsp;&nbsp;&nbsp;&nbsp;&ensp;&nbsp;&nbsp;     {ele.orderId}
                                        </div>
                                </td>
                                <td>
                                <div className="row-lg-4"><br/>
                                &ensp;&ensp; &ensp;&nbsp;&ensp;&nbsp;&nbsp;&nbsp;&nbsp;&ensp;&nbsp;&nbsp;   {ele.orderDate}
                                        </div>
                           
                                </td>
                                <td>
                                <div className="row-lg-4"><br/>
                                &ensp;&ensp; &ensp;&nbsp;&ensp;&nbsp;&nbsp;&nbsp;&nbsp;&ensp;&nbsp;&nbsp;     {ele.orderprice}
                                        </div>
                                </td>
                                </tr>
                             
                                    {/* < CardContent>
                                        <Typography gutterBottom variant="h5" component="div" >
                                            <input type="number" min="1" defaultValue="1" onChange={(e) => {
                                            item.qty=e.target.value ;cart.push(item);
                                                qtymanage(ele, e.target.value)
                                            }} readonly />&nbsp;
                                        </Typography>
                                    </CardContent> */}
                              
                                    {/* < CardContent>
                                        <Typography gutterBottom variant="h5" component="div" >
                                            {ele.sellingPrice}
                                        </Typography>
                                        <Typography variant="body2" color="text.secondary">
                                        </Typography>
                                    </CardContent> */}
                               
                              
                            </span>)
                    })
                }
           </div>
           </div>
         
            </center>
            </h1>

        </div>
    )
}
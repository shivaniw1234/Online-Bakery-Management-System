import axios from "axios";
import Header from "./header"
import { Link, useLocation } from 'react-router-dom';
import { useEffect } from "react";

export default function Order()
{
    
    useEffect(() =>{
        let orderdet={}
        orderdet.userId= sessionStorage.getItem("userid");
        let today=new Date();
        orderdet.orderDate=today.getFullYear()+"-"+today.getMonth()+"-"+today.getDate();
        console.log("orderDate: " + orderdet);
        // console.log("uid",uid);
      
        axios.get("http://localhost:8080/order/details",orderdet)
        .then((res)=>{console.log("order",res.data)}).catch((err )=>{console.log("error",err)});
     },[]);


    return(
        <div>
            <Header></Header>
        
            

        </div>
    )
}
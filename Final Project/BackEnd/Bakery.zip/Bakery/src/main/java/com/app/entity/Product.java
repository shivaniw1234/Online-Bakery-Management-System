package com.app.entity;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.Lob;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import org.springframework.web.multipart.MultipartFile;

@Entity
@Table(name="product_tbl")
public class Product {
	
	@Id
	@Column(name="product_id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private int prodId;
	
	@Column(name="product_name")
	private String prodName;
	
	@Column(name="category_name")
	private String categoryName;
	
	@Column(name="product_selling_price")
	private float sellingPrice;
	
	private int stock;
	
	@Lob
	private byte [] product_img;
	
//	@ManyToMany
//	@JoinTable(name="product_order_tbl", joinColumns= 
//	@JoinColumn(name="product_id" ,referencedColumnName = "product_id"),
//	inverseJoinColumns =@JoinColumn(name="order_id",referencedColumnName = "order_id"))
//	List<Order> orders;
	
//	@ManyToMany
//	@JoinTable(name="product_cart_details_tbl", joinColumns= 
//	@JoinColumn(name="product_id" ,referencedColumnName = "product_id"),
//	inverseJoinColumns =@JoinColumn(name="cart_id",referencedColumnName = "cart_id"))
//	List<Cart> carts;
	
	public Product( String prodName, String categoryName, float sellingPrice, int stock,byte [] img) {
	super();
	this.prodName = prodName;
	this.categoryName = categoryName;
	this.sellingPrice = sellingPrice;
	this.stock = stock;
	this.product_img=img;
	}

	
	
public Product(String prodName, String categoryName, float sellingPrice, int stock) {
	super();
	this.prodName = prodName;
	this.categoryName = categoryName;
	this.sellingPrice = sellingPrice;
	this.stock = stock;
}



//	public Product(String prodName, String categoryName, float sellingPrice, int stock) {
//	super();
//	this.prodName = prodName;
//	this.categoryName = categoryName;
//	this.sellingPrice = sellingPrice;
//	this.stock = stock;
//}


	public byte[] getProduct_img() {
		return product_img;
	}


	public void setProduct_img(byte[] product_img) {
		this.product_img = product_img;
	}


	public Product() {
		super();
	}


	public int getProdId() {
		return prodId;
	}

	public void setProdId(int prodId) {
		this.prodId = prodId;
	}

	public String getProdName() {
		return prodName;
	}

	public void setProdName(String prodName) {
		this.prodName = prodName;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public float getSellingPrice() {
		return sellingPrice;
	}

	public void setSellingPrice(float sellingPrice) {
		this.sellingPrice = sellingPrice;
	}

	public int getStock() {
		return stock;
	}

	public void setStock(int stock) {
		this.stock = stock;
	}

	

}

package com.app.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.app.entity.Cart;
import com.app.entity.Cart2;
import com.app.entity.Product;
import com.app.entity.User;
import com.app.repository.Cart2Repository;
import com.app.repository.CartRepository;
import com.app.repository.ProductRepository;

@Service
public class CartService {
	
	@Autowired
	CartRepository crep2;
	
	@Autowired
	Cart2Repository crep;
	
	@Autowired
	ProductRepository prep;
	
	//HashMap<Integer,Integer> prodQty=new HashMap<Integer,Integer>();
	
	
	
	
	
	public boolean remove(@RequestBody Cart2 c)
	{
		
//		User u=urep.findById(uid).get();
//		if(u!=null) {
			List<Cart2> carts=crep.findByUserId(c.getUserId());
		
			for(int i = 0; i < carts.size(); i++){
				Product p=prep.findById(carts.get(i).getProductId()).get();
				if(c.getProductId()==p.getProdId())
				{
					Cart2 c2=crep.CheckCart(c.getUserId(), c.getProductId());
					if(c2!=null)
					{
						crep.deleteById(c2.getCartId());
						return true;
					}
					else
						return false;
				}
				
			}
		
		return false;
//		return cserv.removeFromCart(c);
	}
	
	
	
	

}

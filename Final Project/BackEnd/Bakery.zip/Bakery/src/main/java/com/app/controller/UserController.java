package com.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.DO.UserDO;
import com.app.entity.Cart;
import com.app.entity.User;
import com.app.repository.CartRepository;
import com.app.repository.UserRepository;
import com.app.service.UserServices;

@CrossOrigin("*")
@RestController
@RequestMapping(path="user")
public class UserController {
	@Autowired
	UserRepository urep;
	
	@Autowired
	UserServices userv;
	
	@Autowired
	CartRepository crep;
	
	public UserController()
	{
		System.out.println("User controller created");
	}
	

	@PostMapping("/register")
	public User registerUser(@RequestBody User u)
	{
		User u1=new User(u.getFirstName(),u.getLastName(),u.getEmailId(),u.getPassword(),u.getPhoneNo(),u.getRole());
//		Cart c1=new Cart();
//		c1.setUser(u1);
//		u1.setCart(c1);
		User u2=userv.addUser(u1);
		Cart c1=new Cart();
		c1.setUser(u2);
		crep.save(c1);
		return u2;
		
//				User u2=userv.addUser(u1);

	}
	
	@PostMapping("/loginCust")
	public String checkLoginCust(@RequestBody UserDO u)
	{
//		return urep.CheckLoginCustomer(u.getEmailId(), u.getPassword());
	return userv.checkLoginCustomer(u.getEmailId(), u.getPassword());
	}
	
	@PostMapping("/loginCustomer")
	public User checkLoginCustomer(@RequestBody UserDO u)
	{
//		return urep.CheckLoginCustomer(u.getEmailId(), u.getPassword());
	return urep.CheckLoginCustomer(u.getEmailId(), u.getPassword());
	}
	
	@PostMapping("/loginAd")
	public String checkLoginAdmin(@RequestBody UserDO u)
	{
	
		return userv.checkLoginAdmin(u.getEmailId(), u.getPassword());
		
	}
	
	
	@GetMapping("/getAll")
	public List<User> getAllCustomer()
	{
		return userv.getAllCustomers();
	}
	
	
	@PutMapping("changepwd/{uname}/{oldpwd}/{newpwd}")
	public User changePassword(@PathVariable String uname,@PathVariable String oldpwd,@PathVariable String newpwd)
	{
		User u=userv.changePassword(uname, oldpwd, newpwd);
		return u;
	}
	
	@GetMapping("/getId/{email}")
	public int findByUser(@PathVariable String email)
	{
		User u= urep.findByEmailId(email);
//		User u1=urep.findByPassword(email);
		if(u !=null)
		{
			return u.getId();
		}
		else
			return 0;
	}

	@GetMapping("/get/{uid}")
	public User findId(@PathVariable int uid)
	{
		return urep.findById(uid).get();
	
	}
	
	


}

package com.app.DO;

import java.sql.Date;
import java.text.DecimalFormat;
import java.time.LocalDateTime;

import javax.persistence.Column;

public class OrderDO {
	
	private int orderid;
	private int[] productId;
	private int userId;
	private String orderDate;
	private Float orderprice;
	private String paymentMode;
	private String paymentStatus;
	
	public OrderDO() {
		super();
	}

	public OrderDO(int[] productId, int userId,String orderDate, String paymentMode, String paymentStatus) {
		super();
		this.productId = productId;
		this.userId = userId;
		this.orderDate = orderDate;
		this.paymentMode = paymentMode;
		this.paymentStatus = paymentStatus;
	}
	
	

	public OrderDO(int userId, String orderDate) {
		super();
		this.userId = userId;
		this.orderDate = orderDate;
	}

	public OrderDO(int[] productId, int userId) {
		super();
		this.productId = productId;
		this.userId = userId;
	}

	public int getUserId() {
		return userId;
	}


	public void setUserId(int userId) {
		this.userId = userId;
	}


	public int getOrderid() {
		return orderid;
	}
	public void setOrderid(int orderid) {
		this.orderid = orderid;
	}
	public int[] getProductId() {
		return productId;
	}
	public void setProductId(int []productId) {
		this.productId = productId;
	}

	public String getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}

	public Float getOrderprice() {
		return orderprice;
	}

	public void setOrderprice(Float orderprice) {
		this.orderprice = orderprice;
	}

	public String getPaymentMode() {
		return paymentMode;
	}

	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}

	public String getPaymentStatus() {
		return paymentStatus;
	}

	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}
	
	

}
